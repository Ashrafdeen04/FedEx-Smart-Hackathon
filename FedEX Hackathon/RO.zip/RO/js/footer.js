document.getElementById("footer").innerHTML = `
  <div class="container">
    <p>&copy; 2023 FedEx Dynamic Routing System. All rights reserved.</p>
  </div>
`;
